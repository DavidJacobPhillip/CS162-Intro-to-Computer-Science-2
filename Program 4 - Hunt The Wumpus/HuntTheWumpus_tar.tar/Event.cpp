#include <iostream>
#include <cstdlib>
#include <string>
#include "Event.hpp"

using namespace std;

Event::Event(){

}

Event::~Event(){

}