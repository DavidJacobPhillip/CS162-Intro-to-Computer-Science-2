#include <iostream>
#include <cstdlib>
#include <string>
#include "Sealion.hpp"

using namespace std;

Sealion::Sealion() : Animal ("sealion"){
	// cout << "sealion constructor called" << endl;
}

Sealion::~Sealion(){

}





