#include <iostream>
#include <cstdlib>
#include <string>
#include "Tiger.hpp"

using namespace std;
Tiger::Tiger() : Animal("tiger"){
	//cout << "tiger constructor called " << endl;
}

Tiger::~Tiger(){

}


