#include <iostream>
#include <cstdlib>
#include <string>
#include "Bear.hpp"

using namespace std;

Bear::Bear() : Animal ("bear"){
	// cout << "bear constructor called" << endl;
}

Bear::~Bear(){

}



